# Quotex Signal Prototype — Android

This is the first prototype for a **signal-only** Android screen analyzer.

It does NOT:
- click Quotex buttons
- place trades
- execute Up/Down automatically
- claim 100% accuracy

It DOES:
- request Android screen-capture permission
- run a MediaProjection foreground service
- capture the phone screen periodically
- save the latest frame as `latest_frame.png` in the app's external files area

## Build

Open this folder in Android Studio and let Gradle sync.

Recommended:
- Android Studio current stable
- JDK 17
- Android SDK Platform 35

Then:
Build > Build APK(s)

Install the generated debug APK on the Android phone.

## First test

1. Install and open the app.
2. Allow "Display over other apps" when asked.
3. Tap START SCREEN ANALYZER.
4. Approve Android's screen-capture dialog.
5. Open the Quotex chart.
6. Return to the prototype if needed to stop capture.

## Next engineering stage

The saved frame is intentionally the first milestone. Next we add:
1. chart-region detection
2. candle detection
3. OHLC extraction
4. trend/structure features
5. strategy engine
6. backtest logger
7. UP/DOWN/WAIT signal UI

The signal engine should only emit a trade direction when the measured conditions pass the configured threshold; otherwise it emits WAIT.
