package com.example.quotexsignal

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.quotexsignal.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val captureRequest = 9001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.startButton.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Allow 'Display over other apps', then press Start again.", Toast.LENGTH_LONG).show()
                startActivity(Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                ))
                return@setOnClickListener
            }

            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
        }

        binding.stopButton.setOnClickListener {
            stopService(Intent(this, CaptureService::class.java))
            binding.statusText.text = "Status: stopped"
            binding.signalText.text = "WAIT\n\nAnalyzer stopped."
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != captureRequest || resultCode != Activity.RESULT_OK || data == null) {
            binding.statusText.text = "Status: permission cancelled"
            return
        }

        val serviceIntent = Intent(this, CaptureService::class.java).apply {
            putExtra("resultCode", resultCode)
            putExtra("resultData", data)
        }

        androidx.core.content.ContextCompat.startForegroundService(this, serviceIntent)
        binding.statusText.text = "Status: screen analyzer running"
        binding.signalText.text = "WAIT\n\nCapture started.\nSignal engine is not active yet."
    }
}
